from pathlib import Path
import sys, os, re, json, hashlib, time, uuid, subprocess
from zipfile import ZipFile, ZIP_DEFLATED
from datetime import datetime
repo=Path(r'C:/Users/Agent/Cyclone/cloak-repo'); sys.path.insert(0,str(repo/'tools'))
import profile_check as pc
apk=repo/'android/probe/build/outputs/apk/diagnostics/debug/probe-diagnostics-debug.apk'
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
if commit!='fbdc0faa5330bb0672894eb3110318307d738816': raise RuntimeError('WRONG_COMMIT')
if subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=repo,text=True).strip(): raise RuntimeError('TRACKED_WORKTREE_DIRTY')
out=repo/'docs/runtime-evidence'/datetime.now().astimezone().strftime('%Y-%m-%d-run3-expectations-%H%M%S'); out.mkdir(); (out/'.gitignore').write_text('*\n')
(Path(os.environ['TEMP'])/'cloak-run3-output.txt').write_text(str(out))
d=pc.Device('C:/Users/Agent/android-sdk/platform-tools/adb.exe','3B171FDJH0061G',90); user=int(d.shell('am get-current-user').stdout.strip()); pkg=pc.PACKAGE
if user!=0 or d.shell('am get-started-user-state 0').stdout.strip()!='RUNNING_UNLOCKED': raise RuntimeError('EXPECTED_UNLOCKED_USER_ZERO')
m=dict(format=1,run_id=uuid.uuid4().hex,scenario='run3-expectations-bound-a-repeat-b',started_at=pc.utc(),started_epoch=time.time(),user=user,target_user=user,full_profile=False,phases={},source_commit=commit,apk_sha256=hashlib.sha256(apk.read_bytes()).hexdigest(),no_user_transition=True,permission_changes=False)
h=pc.Harness(out,m,d,apk); reports=[]; checks=[]; errors=[]; before=None; original_permissions=None

def permissions():
 s=d.shell('dumpsys package '+pkg).stdout.split('\nQueries:')[0]; users={}
 for match in re.finditer(r'^    User (\d+):.*?(?=^    User |^\S|\Z)',s,re.M|re.S):
  users[match[1]]={p:dict(granted=v=='true',flags=[x.strip() for x in f.split('|') if x.strip()]) for p,v,f in re.findall(r'(android\.permission\.[A-Z_]+): granted=(true|false), flags=\[([^\]]*)\]',match[0])}
 return users

def audit():
 raw,index=d.index()
 if f'{user}/{pkg}' in index['entries']: raise RuntimeError('DIAGNOSTICS_BINDING_ALREADY_EXISTS')
 def fp(command):
  lines=d.root(command).stdout.splitlines(); return dict(count=len(lines),sha256=hashlib.sha256('\n'.join(sorted(lines)).encode()).hexdigest())
 return dict(production_entry_count=len(index['entries']),index_semantic_sha256=pc.digest(index),index_raw_sha256=hashlib.sha256(raw.encode()).hexdigest(),module_files=fp('find /data/adb/modules/cyclone_cloak -type f -exec sha256sum {} \\;'),publisher_shares=fp('find /data/adb/cyclone_cloak/publishers -type f -exec sha256sum {} \\;'),published_bodies=fp('find /data/adb/cyclone_cloak/state-v1 -type f ! -name index.json -exec sha256sum {} \\;'),binding_stores=fp('for u in /data/user/[0-9]*; do f="$u/dev.cyclone.cloak/no_backup/cloak-bindings-v1.json"; if [ -f "$f" ]; then sha256sum "$f"; fi; done'))

try:
 original_permissions=permissions(); pc.save(out/'permissions-before.json',original_permissions)
 print('Auditing production before run...',flush=True); before=audit(); pc.save(out/'audit-before.json',before)
 pc.save(out/'environment.json',h.environment())
 aapt='C:/Users/Agent/android-sdk/build-tools/35.0.0/aapt.exe'
 badging=subprocess.run([aapt,'dump','badging',str(apk)],capture_output=True,text=True,check=True).stdout
 if not re.search(r"^package: name='dev\.cyclone\.cloak\.probe\.diag'",badging,re.M): raise RuntimeError('NOT_DIAGNOSTICS_APK')
 installed=d.run('install','--user',user,'-r',apk.resolve(),timeout=90)
 if 'Success' not in installed.stdout: raise RuntimeError('INSTALL_FAILED')
 path=d.shell(f'pm path --user {user} {pkg}').stdout.splitlines()[0].removeprefix('package:')
 import shlex
 m['installed_apk_sha256']=d.root('sha256sum '+shlex.quote(path)).stdout.split()[0]
 if m['installed_apk_sha256']!=m['apk_sha256']: raise RuntimeError('INSTALLED_APK_MISMATCH')
 for name,label in [('bound-a','a'),('bound-a-repeat','a'),('bound-b','b')]:
  item=dict(kind='fixture',fixture=label,user=user,target_count=1); body=h.body(item); item.update(sha256=pc.digest(body),profile_id=body['id'])
  m['selections']=[item]; m['overlay_active']=True; h.checkpoint(); h.overlay()
  key=pc.digest([m['run_id'],user]); published=d.root(f'sha256sum {pc.STATE}/{key}/profile.json').stdout.split()[0]
  _,idx=d.index(); entry=idx['entries'].pop(f'{user}/{pkg}')
  production_ok=pc.digest(idx)==before['index_semantic_sha256']
  if not production_ok: raise RuntimeError('PRODUCTION_ENTRIES_CHANGED')
  r=h.capture(item,cold=True); r['run']=name; pc.save(out/(name+'.json'),r); reports.append(r)
  check=dict(run=name,expected_fixture=label,report_fixture=r['fixture'],fixture_sha256=item['sha256'],report_profile_sha256=r['profile_sha256'],temporary_published_sha256=published,bound_profile_id_matches=entry['cloakProfileId']==item['profile_id'],production_entries_preserved=production_ok)
  check['match']=r['fixture']==label and item['sha256']==r['profile_sha256']==published and check['bound_profile_id_matches']; checks.append(check); pc.save(out/'fixture-hash-checks.json',checks)
  print(name,json.dumps(pc.classify([r])),flush=True)
  if not check['match']: raise RuntimeError('FIXTURE_HASH_MISMATCH')
  bad=[row for row in r['rows'] if row['status'] in ('FAIL','MISSING')]
  if bad: pc.save(out/'unexpected-rows.json',bad); raise RuntimeError('UNEXPECTED_ROW_FAILURE')
except Exception as e:
 errors.append(str(e) if re.fullmatch('[A-Z_]+',str(e)) else type(e).__name__); print('STOP',errors[-1],flush=True)
finally:
 try:
  if m.get('overlay_active'): m['cleanup']=h.overlay(remove=True)
  d.shell(f'am force-stop --user {user} {pkg}',check=False)
  # Delete only the two diagnostics app-private temporary report inputs/outputs.
  d.shell(f'run-as {pkg} --user {user} rm -f files/expected-profile.json files/report.json')
  key=pc.digest([m['run_id'],user]); scratch='/data/local/tmp/cloak-profile-check-'+m['run_id']
  cleanup_command=f'test ! -e {pc.STATE}/{key}; test ! -e {scratch}; test ! -e {pc.STATE}/index.harness-{m["run_id"]}'
  m['temporary_files_removed']=d.root(cleanup_command,check=False).returncode==0
  m['probe_private_temporary_files_removed']=d.shell(f'run-as {pkg} --user {user} sh -c "test ! -e files/expected-profile.json; test ! -e files/report.json"',check=False).returncode==0
  if not m['temporary_files_removed'] or not m['probe_private_temporary_files_removed']: errors.append('TEMPORARY_STATE_REMAINS')
  print('Auditing production after cleanup...',flush=True); after=audit(); pc.save(out/'audit-after.json',after)
  m['preservation']={k:before[k]==after[k] for k in before} if before else {}
  if before and not all(m['preservation'].values()): errors.append('PRODUCTION_AUDIT_MISMATCH')
  now=permissions(); pc.save(out/'permissions-after.json',now); m['permissions_unchanged']=now==original_permissions
  if not m['permissions_unchanged']: errors.append('PERMISSION_STATE_CHANGED')
  m['foreground_user_unchanged']=int(d.shell('am get-current-user').stdout.strip())==user
  pc.save(out/'crash-evidence.json',h.crash_log())
 except Exception as e: errors.append('CLEANUP_OR_AUDIT_FAILED:'+type(e).__name__)
 differences=[]
 for left,right in zip(reports,reports[1:]):
  rows=pc.compare(left,right); differences.extend(rows); pc.save(out/(left['run']+'-to-'+right['run']+'-diff.json'),rows)
 verdict=pc.classify(reports,differences,phase_failures=len(errors)); pc.save(out/'classification.json',verdict)
 policies={r['run']:[row for row in r['rows'] if row.get('expectation_policy')] for r in reports}; pc.save(out/'policy-outcomes.json',policies)
 stable=[dict(from_run=left['run'],to_run=right['run'],**v) for left,right in zip(reports,reports[1:]) for v in pc.compare(left,right) if v['id']=='runtime.javaBridgeVisible']; pc.save(out/'stability-checks.json',stable)
 m.update(finished_at=pc.utc(),duration_seconds=round(time.time()-m['started_epoch'],2),errors=errors,completed_runs=[r['run'] for r in reports]); h.checkpoint()
 pc.save(out/'build-provenance.json',dict(source_commit=commit,apk_path=str(apk),apk_sha256=m['apk_sha256'],installed_apk_sha256=m.get('installed_apk_sha256'),build_command='$env:JAVA_HOME="C:/Program Files/Eclipse Adoptium/jdk-17.0.20.101-hotspot"; $env:CLOAK_TEST_WSL="1"; & "$env:TEMP/cloak-build/gradle-8.11.1/bin/gradle.bat" -p android :probe:assembleDiagnosticsDebug --offline --no-daemon --console=plain',build_result='BUILD SUCCESSFUL',runner='existing profile_check.Harness.overlay/capture and compare; same Android user only'))
 lines=['# Run 3 diagnostics expectation validation','',f'Result: {verdict["result"]}',f'Duration: {m["duration_seconds"]} seconds',f'Commit: {commit}',f'APK SHA-256: {m["apk_sha256"]}',f'Errors: {errors}','', '| Capture | PASS | OBSERVED | BLOCKED | FAIL | MISSING |','|---|---:|---:|---:|---:|---:|']
 for r in reports:
  counts=pc.classify([r])['statuses']; lines.append('| '+r['run']+' | '+' | '.join(str(counts.get(k,0)) for k in ['PASS','OBSERVED','BLOCKED','FAIL','MISSING'])+' |')
 lines+=['', 'Paired classification: '+json.dumps(verdict), 'Stability: '+json.dumps(stable), 'Production preservation: '+json.dumps(m.get('preservation')), 'Fixture/hash checks: '+str(all(c['match'] for c in checks)), 'Permissions unchanged: '+str(m.get('permissions_unchanged')), 'Temporary state removed: '+str(m.get('temporary_files_removed') and m.get('probe_private_temporary_files_removed')), '', 'Scope: diagnostics APK only. No module/app install, user switch, reboot, permission modification, connector call or production store write. Values redacted to comparison hashes. External observations are not passes. Paired stability here means fixture A/B in the same Android user, not an Android-user transition. Permission denial is not physically exercised unless already denied. Installed module file digest does not prove in-memory binary identity. Locked other users private stores are outside the audit. No historical evidence reclassified; no platform verdict.']
 (out/'summary.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
 with ZipFile(out/'evidence-bundle.zip','w',ZIP_DEFLATED) as z:
  for p in out.iterdir():
   if p.is_file() and p.suffix in ('.json','.md','.log'): z.write(p,p.name)
 print('EVIDENCE',out,flush=True); print('FINAL',json.dumps(verdict),flush=True)
