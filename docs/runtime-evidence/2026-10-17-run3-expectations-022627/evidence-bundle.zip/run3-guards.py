from pathlib import Path
import os,sys,json,copy
repo=Path(r'C:/Users/Agent/Cyclone/cloak-repo'); sys.path.insert(0,str(repo/'tools'))
import profile_check as pc
out=Path((Path(os.environ['TEMP'])/'cloak-run3-output.txt').read_text()); a=json.loads((out/'bound-a.json').read_text()); b=json.loads((out/'bound-b.json').read_text())
def stable(left,right): return next(v for v in pc.compare(left,right) if v['id']=='runtime.javaBridgeVisible')
cases={'unmodified_distinct_captures':stable(a,b)}
for name in ('same_capture_id','different_artifact','missing_artifact','different_rule','missing_value_evidence'):
 changed=copy.deepcopy(b); row=next(r for r in changed['rows'] if r['id']=='runtime.javaBridgeVisible')
 if name=='same_capture_id': changed['request_id']=a['request_id']
 if name=='different_artifact': changed['artifact']='0'*64
 if name=='missing_artifact': changed.pop('artifact')
 if name=='different_rule': row['expectation_rule_sha256']='0'*64
 if name=='missing_value_evidence': row['actual_available']=False
 cases[name]=stable(a,changed)
assert cases['unmodified_distinct_captures']['status']=='PASS'
assert all(v['status']=='OBSERVED' and v['severity']=='WARNING' for k,v in cases.items() if k!='unmodified_distinct_captures')
pc.save(out/'stability-metadata-guards.json',dict(scope='Host-only negative controls using copies of fresh Run 3 reports; original reports untouched',cases=cases))
print(json.dumps(cases,indent=2))
